// Verify admin/moderator role
