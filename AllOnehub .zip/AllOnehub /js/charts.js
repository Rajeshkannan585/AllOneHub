// Chart.js dashboard helpers
