import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js";

const firebaseConfig = {
  apiKey: "AIzaSyDg-xvWf3WIP3vt_TJsvlmM8l9OxxoGS-w",
  authDomain: "x-plateau-466020-f7.firebaseapp.com",
  projectId: "x-plateau-466020-f7",
  storageBucket: "x-plateau-466020-f7.firebasestorage.app",
  messagingSenderId: "553602612199",
  appId: "1:553602612199:web:f0fadf7669b52a023b1b42"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);